package ${PACKAGE_NAME};

import com.rachio.core.db.model.AbstractRachioDAO;
import com.rachio.device.db.model.$MODEL_NAME;
import org.hibernate.SessionFactory;


public class ${NAME} extends AbstractRachioDAO<$MODEL_NAME, String> {
  public ${NAME}(SessionFactory sessionFactory) {
    super(sessionFactory);
  }
}
