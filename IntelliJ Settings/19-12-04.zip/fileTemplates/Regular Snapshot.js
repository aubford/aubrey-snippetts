// @flow
import * as React from 'react'
import Component from './index'
import {initTestRunner} from '$DOTS../../../test-utils/testingAPI'

Date.now = jest.fn(() => 1487076708000)

test('$Name component matches snapshot', () => { 
    const comp = initTestRunner(
        <Component
            widthId={'lg'}
            style={{
                color: 'red',
                backgroundColor: 'blue',
                width: 100,
                height: 100
            }}
            #[[$END$]]#
        />
    )
    
    comp.verifySnapshot() 
})
