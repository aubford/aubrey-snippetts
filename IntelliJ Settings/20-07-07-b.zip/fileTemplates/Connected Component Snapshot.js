// @flow
import * as React from 'react'
import Component from './index'
import {initHOCTestRunner} from '$Dots../../../test-utils/testingAPI'
import {buildContainerProps} from '$Dots../../../test-utils/helpers'
import {deviceSnapshotStore, MOCK_LOCATION_ID} from '$Dots../../../test-utils/snapshotStore'

jest.useFakeTimers()
Date.now = jest.fn(() => 1487076708000)

jest.mock('$Dots../../util/api.js', () => ({
  API: () => ({
    call: () => Promise.resolve({})
  }),
  loadDataSerialSimple: () => Promise.resolve({}),
  loadDataParallelSimple: () => Promise.resolve({}),
  notNull: input => input !== null 
}))

let comp
beforeAll(() => {
  const store = deviceSnapshotStore()
  comp = initHOCTestRunner(
    <Component
      store={store}
      {...buildContainerProps({ locationId: MOCK_LOCATION_ID })}
    />
  )
})

test('$Name container matches snapshot', () => {
    comp.update()
    comp.verifySnapshot() 
})
