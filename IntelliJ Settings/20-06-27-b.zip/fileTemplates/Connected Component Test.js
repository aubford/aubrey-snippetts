// @flow
import * as React from 'react'
import Component from './index'
import { buildContainerProps, initHOCTestRunner } from '$Dots../../../test-utils/testingAPI'
import { mockStoreSimple } from '$Dots../../../test-utils/mockStore'
import aRandom from '$Dots../../../test-utils/aRandom'

jest.useFakeTimers()
const locationId = aRandom.guid()
const deviceId = aRandom.guid()

jest.mock('$Dots../../../util/api.js', () => {
  const actual = require.requireActual('$Dots../../../util/api.js')
  return {
    ...actual,
    API: () => ({
        call: () => Promise.resolve({})
    }),
    notNull: input => input !== null
  }
})

let testRunner
beforeAll(() => {
  const store = mockStoreSimple({
    locationId,
    deviceId
  })
  testRunner = initHOCTestRunner(
    <Component
      store={store}
      {...buildContainerProps({
        locationId,
        deviceId
      })}
    />,
    true
  )
})

afterAll(() => {
  testRunner.done()
})

describe('$Name container ', () => {
  test('should be done with data load phase', () => {
    testRunner.update()
    expect(testRunner.getState().$LoadingKey).toBe(false)
  })

  test('renders correctly', () => {
    testRunner.verifyRender([$renders])
  })


  test('responds to user interaction correctly', () => {
    testRunner.performTouchTaps(
      [$touchTaps]
    )
  })
})
